#!/bin/sh
konsole -e "java -Xmx1024M -Xms1024M -jar spigot-1.16.4.jar nogui"
